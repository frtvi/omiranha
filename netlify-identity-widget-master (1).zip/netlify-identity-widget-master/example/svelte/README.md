# svelte example

[@babycourageous](https://github.com/babycourageous) has an example of how to use the `netlify-identity-widget` with Svelte.

- [Repo](https://github.com/babycourageous/netlify-identity-demo-svelte)
- [example website](https://netlify-identity-demo-svelte.netlify.com/)
